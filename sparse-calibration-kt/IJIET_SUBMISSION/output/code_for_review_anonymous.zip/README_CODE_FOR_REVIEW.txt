Anonymous code bundle for IJIET double-blind review

This zip is the reviewer-facing code supplement. It does not contain:
- paper/main_jedm.tex, paper/main_jedm.pdf, jedm_upload_folder/main_jedm.tex
- named IJIET Word sources
- multi-GB a2b data dumps or prediction files

It does contain local training/evaluation scripts, table CSVs used by the
8-page manuscript, and a2b Python (no processed logs). Public benchmarks
must be obtained from the original providers (ASSISTments 2012, Junyi
Academy, XES3G5M).

Do not treat the Transformer KT baseline as published SimpleKT.
